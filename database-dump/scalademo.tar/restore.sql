--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.15 (Ubuntu 12.15-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.15 (Ubuntu 12.15-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE scala_demo;
--
-- Name: scala_demo; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE scala_demo WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_IN' LC_CTYPE = 'en_IN';


ALTER DATABASE scala_demo OWNER TO postgres;

\connect scala_demo

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: movies; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA movies;


ALTER SCHEMA movies OWNER TO postgres;

--
-- Name: play_silhouette; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA play_silhouette;


ALTER SCHEMA play_silhouette OWNER TO postgres;

--
-- Name: scala_demo_owner; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA scala_demo_owner;


ALTER SCHEMA scala_demo_owner OWNER TO postgres;

--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA movies;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Actor; Type: TABLE; Schema: movies; Owner: postgres
--

CREATE TABLE movies."Actor" (
    actor_id bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE movies."Actor" OWNER TO postgres;

--
-- Name: ActorDetails; Type: TABLE; Schema: movies; Owner: postgres
--

CREATE TABLE movies."ActorDetails" (
    id bigint NOT NULL,
    actor_id bigint NOT NULL,
    personal_info jsonb NOT NULL
);


ALTER TABLE movies."ActorDetails" OWNER TO postgres;

--
-- Name: ActorDetails_id_seq; Type: SEQUENCE; Schema: movies; Owner: postgres
--

CREATE SEQUENCE movies."ActorDetails_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies."ActorDetails_id_seq" OWNER TO postgres;

--
-- Name: ActorDetails_id_seq; Type: SEQUENCE OWNED BY; Schema: movies; Owner: postgres
--

ALTER SEQUENCE movies."ActorDetails_id_seq" OWNED BY movies."ActorDetails".id;


--
-- Name: Actor_actor_id_seq; Type: SEQUENCE; Schema: movies; Owner: postgres
--

CREATE SEQUENCE movies."Actor_actor_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies."Actor_actor_id_seq" OWNER TO postgres;

--
-- Name: Actor_actor_id_seq; Type: SEQUENCE OWNED BY; Schema: movies; Owner: postgres
--

ALTER SEQUENCE movies."Actor_actor_id_seq" OWNED BY movies."Actor".actor_id;


--
-- Name: Movie; Type: TABLE; Schema: movies; Owner: postgres
--

CREATE TABLE movies."Movie" (
    movie_id bigint NOT NULL,
    name character varying NOT NULL,
    release_date date NOT NULL,
    length_in_min integer NOT NULL
);


ALTER TABLE movies."Movie" OWNER TO postgres;

--
-- Name: MovieActorMapping; Type: TABLE; Schema: movies; Owner: postgres
--

CREATE TABLE movies."MovieActorMapping" (
    movie_actor_id bigint NOT NULL,
    movie_id bigint NOT NULL,
    actor_id bigint NOT NULL
);


ALTER TABLE movies."MovieActorMapping" OWNER TO postgres;

--
-- Name: MovieActorMapping_movie_actor_id_seq; Type: SEQUENCE; Schema: movies; Owner: postgres
--

CREATE SEQUENCE movies."MovieActorMapping_movie_actor_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies."MovieActorMapping_movie_actor_id_seq" OWNER TO postgres;

--
-- Name: MovieActorMapping_movie_actor_id_seq; Type: SEQUENCE OWNED BY; Schema: movies; Owner: postgres
--

ALTER SEQUENCE movies."MovieActorMapping_movie_actor_id_seq" OWNED BY movies."MovieActorMapping".movie_actor_id;


--
-- Name: MovieLocations; Type: TABLE; Schema: movies; Owner: postgres
--

CREATE TABLE movies."MovieLocations" (
    movie_location_id bigint NOT NULL,
    movie_id bigint NOT NULL,
    locations text[] NOT NULL
);


ALTER TABLE movies."MovieLocations" OWNER TO postgres;

--
-- Name: MovieLocations_movie_location_id_seq; Type: SEQUENCE; Schema: movies; Owner: postgres
--

CREATE SEQUENCE movies."MovieLocations_movie_location_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies."MovieLocations_movie_location_id_seq" OWNER TO postgres;

--
-- Name: MovieLocations_movie_location_id_seq; Type: SEQUENCE OWNED BY; Schema: movies; Owner: postgres
--

ALTER SEQUENCE movies."MovieLocations_movie_location_id_seq" OWNED BY movies."MovieLocations".movie_location_id;


--
-- Name: MovieProperties; Type: TABLE; Schema: movies; Owner: postgres
--

CREATE TABLE movies."MovieProperties" (
    id bigint NOT NULL,
    movie_id bigint NOT NULL,
    properties movies.hstore NOT NULL
);


ALTER TABLE movies."MovieProperties" OWNER TO postgres;

--
-- Name: MovieProperties_id_seq; Type: SEQUENCE; Schema: movies; Owner: postgres
--

CREATE SEQUENCE movies."MovieProperties_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies."MovieProperties_id_seq" OWNER TO postgres;

--
-- Name: MovieProperties_id_seq; Type: SEQUENCE OWNED BY; Schema: movies; Owner: postgres
--

ALTER SEQUENCE movies."MovieProperties_id_seq" OWNED BY movies."MovieProperties".id;


--
-- Name: Movie_movie_id_seq; Type: SEQUENCE; Schema: movies; Owner: postgres
--

CREATE SEQUENCE movies."Movie_movie_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies."Movie_movie_id_seq" OWNER TO postgres;

--
-- Name: Movie_movie_id_seq; Type: SEQUENCE OWNED BY; Schema: movies; Owner: postgres
--

ALTER SEQUENCE movies."Movie_movie_id_seq" OWNED BY movies."Movie".movie_id;


--
-- Name: StreamingProviderMapping; Type: TABLE; Schema: movies; Owner: postgres
--

CREATE TABLE movies."StreamingProviderMapping" (
    id bigint NOT NULL,
    movie_id bigint NOT NULL,
    streaming_provider character varying NOT NULL
);


ALTER TABLE movies."StreamingProviderMapping" OWNER TO postgres;

--
-- Name: StreamingProviderMapping_id_seq; Type: SEQUENCE; Schema: movies; Owner: postgres
--

CREATE SEQUENCE movies."StreamingProviderMapping_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies."StreamingProviderMapping_id_seq" OWNER TO postgres;

--
-- Name: StreamingProviderMapping_id_seq; Type: SEQUENCE OWNED BY; Schema: movies; Owner: postgres
--

ALTER SEQUENCE movies."StreamingProviderMapping_id_seq" OWNED BY movies."StreamingProviderMapping".id;


--
-- Name: users; Type: TABLE; Schema: play_silhouette; Owner: postgres
--

CREATE TABLE play_silhouette.users (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    "lastName" character varying(64) NOT NULL,
    password character varying(128) NOT NULL,
    email character varying(100) NOT NULL
);


ALTER TABLE play_silhouette.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: play_silhouette; Owner: postgres
--

CREATE SEQUENCE play_silhouette.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE play_silhouette.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: play_silhouette; Owner: postgres
--

ALTER SEQUENCE play_silhouette.users_id_seq OWNED BY play_silhouette.users.id;


--
-- Name: play_evolutions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.play_evolutions (
    id integer NOT NULL,
    hash character varying(255) NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    apply_script text,
    revert_script text,
    state character varying(255),
    last_problem text
);


ALTER TABLE public.play_evolutions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(50),
    email character varying(100)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: Actor actor_id; Type: DEFAULT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."Actor" ALTER COLUMN actor_id SET DEFAULT nextval('movies."Actor_actor_id_seq"'::regclass);


--
-- Name: ActorDetails id; Type: DEFAULT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."ActorDetails" ALTER COLUMN id SET DEFAULT nextval('movies."ActorDetails_id_seq"'::regclass);


--
-- Name: Movie movie_id; Type: DEFAULT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."Movie" ALTER COLUMN movie_id SET DEFAULT nextval('movies."Movie_movie_id_seq"'::regclass);


--
-- Name: MovieActorMapping movie_actor_id; Type: DEFAULT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."MovieActorMapping" ALTER COLUMN movie_actor_id SET DEFAULT nextval('movies."MovieActorMapping_movie_actor_id_seq"'::regclass);


--
-- Name: MovieLocations movie_location_id; Type: DEFAULT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."MovieLocations" ALTER COLUMN movie_location_id SET DEFAULT nextval('movies."MovieLocations_movie_location_id_seq"'::regclass);


--
-- Name: MovieProperties id; Type: DEFAULT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."MovieProperties" ALTER COLUMN id SET DEFAULT nextval('movies."MovieProperties_id_seq"'::regclass);


--
-- Name: StreamingProviderMapping id; Type: DEFAULT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."StreamingProviderMapping" ALTER COLUMN id SET DEFAULT nextval('movies."StreamingProviderMapping_id_seq"'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: play_silhouette; Owner: postgres
--

ALTER TABLE ONLY play_silhouette.users ALTER COLUMN id SET DEFAULT nextval('play_silhouette.users_id_seq'::regclass);


--
-- Data for Name: Actor; Type: TABLE DATA; Schema: movies; Owner: postgres
--

COPY movies."Actor" (actor_id, name) FROM stdin;
\.
COPY movies."Actor" (actor_id, name) FROM '$$PATH$$/3151.dat';

--
-- Data for Name: ActorDetails; Type: TABLE DATA; Schema: movies; Owner: postgres
--

COPY movies."ActorDetails" (id, actor_id, personal_info) FROM stdin;
\.
COPY movies."ActorDetails" (id, actor_id, personal_info) FROM '$$PATH$$/3161.dat';

--
-- Data for Name: Movie; Type: TABLE DATA; Schema: movies; Owner: postgres
--

COPY movies."Movie" (movie_id, name, release_date, length_in_min) FROM stdin;
\.
COPY movies."Movie" (movie_id, name, release_date, length_in_min) FROM '$$PATH$$/3149.dat';

--
-- Data for Name: MovieActorMapping; Type: TABLE DATA; Schema: movies; Owner: postgres
--

COPY movies."MovieActorMapping" (movie_actor_id, movie_id, actor_id) FROM stdin;
\.
COPY movies."MovieActorMapping" (movie_actor_id, movie_id, actor_id) FROM '$$PATH$$/3153.dat';

--
-- Data for Name: MovieLocations; Type: TABLE DATA; Schema: movies; Owner: postgres
--

COPY movies."MovieLocations" (movie_location_id, movie_id, locations) FROM stdin;
\.
COPY movies."MovieLocations" (movie_location_id, movie_id, locations) FROM '$$PATH$$/3157.dat';

--
-- Data for Name: MovieProperties; Type: TABLE DATA; Schema: movies; Owner: postgres
--

COPY movies."MovieProperties" (id, movie_id, properties) FROM stdin;
\.
COPY movies."MovieProperties" (id, movie_id, properties) FROM '$$PATH$$/3159.dat';

--
-- Data for Name: StreamingProviderMapping; Type: TABLE DATA; Schema: movies; Owner: postgres
--

COPY movies."StreamingProviderMapping" (id, movie_id, streaming_provider) FROM stdin;
\.
COPY movies."StreamingProviderMapping" (id, movie_id, streaming_provider) FROM '$$PATH$$/3155.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: play_silhouette; Owner: postgres
--

COPY play_silhouette.users (id, name, "lastName", password, email) FROM stdin;
\.
COPY play_silhouette.users (id, name, "lastName", password, email) FROM '$$PATH$$/3146.dat';

--
-- Data for Name: play_evolutions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.play_evolutions (id, hash, applied_at, apply_script, revert_script, state, last_problem) FROM stdin;
\.
COPY public.play_evolutions (id, hash, applied_at, apply_script, revert_script, state, last_problem) FROM '$$PATH$$/3144.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email) FROM stdin;
\.
COPY public.users (id, name, email) FROM '$$PATH$$/3147.dat';

--
-- Name: ActorDetails_id_seq; Type: SEQUENCE SET; Schema: movies; Owner: postgres
--

SELECT pg_catalog.setval('movies."ActorDetails_id_seq"', 1, false);


--
-- Name: Actor_actor_id_seq; Type: SEQUENCE SET; Schema: movies; Owner: postgres
--

SELECT pg_catalog.setval('movies."Actor_actor_id_seq"', 15, true);


--
-- Name: MovieActorMapping_movie_actor_id_seq; Type: SEQUENCE SET; Schema: movies; Owner: postgres
--

SELECT pg_catalog.setval('movies."MovieActorMapping_movie_actor_id_seq"', 75, true);


--
-- Name: MovieLocations_movie_location_id_seq; Type: SEQUENCE SET; Schema: movies; Owner: postgres
--

SELECT pg_catalog.setval('movies."MovieLocations_movie_location_id_seq"', 1, false);


--
-- Name: MovieProperties_id_seq; Type: SEQUENCE SET; Schema: movies; Owner: postgres
--

SELECT pg_catalog.setval('movies."MovieProperties_id_seq"', 1, false);


--
-- Name: Movie_movie_id_seq; Type: SEQUENCE SET; Schema: movies; Owner: postgres
--

SELECT pg_catalog.setval('movies."Movie_movie_id_seq"', 11, true);


--
-- Name: StreamingProviderMapping_id_seq; Type: SEQUENCE SET; Schema: movies; Owner: postgres
--

SELECT pg_catalog.setval('movies."StreamingProviderMapping_id_seq"', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: play_silhouette; Owner: postgres
--

SELECT pg_catalog.setval('play_silhouette.users_id_seq', 1, true);


--
-- Name: ActorDetails ActorDetails_pkey; Type: CONSTRAINT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."ActorDetails"
    ADD CONSTRAINT "ActorDetails_pkey" PRIMARY KEY (id);


--
-- Name: Actor Actor_pkey; Type: CONSTRAINT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."Actor"
    ADD CONSTRAINT "Actor_pkey" PRIMARY KEY (actor_id);


--
-- Name: MovieActorMapping MovieActorMapping_pkey; Type: CONSTRAINT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."MovieActorMapping"
    ADD CONSTRAINT "MovieActorMapping_pkey" PRIMARY KEY (movie_actor_id);


--
-- Name: MovieLocations MovieLocations_pkey; Type: CONSTRAINT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."MovieLocations"
    ADD CONSTRAINT "MovieLocations_pkey" PRIMARY KEY (movie_location_id);


--
-- Name: MovieProperties MovieProperties_pkey; Type: CONSTRAINT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."MovieProperties"
    ADD CONSTRAINT "MovieProperties_pkey" PRIMARY KEY (id);


--
-- Name: Movie Movie_pkey; Type: CONSTRAINT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."Movie"
    ADD CONSTRAINT "Movie_pkey" PRIMARY KEY (movie_id);


--
-- Name: StreamingProviderMapping StreamingProviderMapping_pkey; Type: CONSTRAINT; Schema: movies; Owner: postgres
--

ALTER TABLE ONLY movies."StreamingProviderMapping"
    ADD CONSTRAINT "StreamingProviderMapping_pkey" PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: play_silhouette; Owner: postgres
--

ALTER TABLE ONLY play_silhouette.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: play_evolutions play_evolutions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.play_evolutions
    ADD CONSTRAINT play_evolutions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_email_uindex; Type: INDEX; Schema: play_silhouette; Owner: postgres
--

CREATE UNIQUE INDEX users_email_uindex ON play_silhouette.users USING btree (email);


--
-- Name: users_id_uindex; Type: INDEX; Schema: play_silhouette; Owner: postgres
--

CREATE UNIQUE INDEX users_id_uindex ON play_silhouette.users USING btree (id);


--
-- PostgreSQL database dump complete
--

